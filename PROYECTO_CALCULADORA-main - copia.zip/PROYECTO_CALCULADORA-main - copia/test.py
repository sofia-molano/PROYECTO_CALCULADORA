import tkinter as tk
import matplotlib.pyplot as plt

# Verificar tkinter
root = tk.Tk()
label = tk.Label(root, text="Tkinter está funcionando!")
label.pack()
root.mainloop()

# Verificar matplotlib
plt.plot([1, 2, 3], [4, 5, 1])
plt.title('Gráfico de prueba de Matplotlib')
plt.show()