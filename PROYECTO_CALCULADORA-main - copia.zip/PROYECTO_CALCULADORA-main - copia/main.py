import sys
sys.path.insert(1,'E:\Personal\UNAL\Primer Semestre\Programacion de Computadores\PROYECTO_CALCULADORA-main\PROYECTO_CALCULADORA-main - copia\view')
import vista

if __name__ == "__main__":
    vista.root.mainloop()